sudo dnf update -y
sudo dnf install langpacks-en glibc-all-langpacks -y
localectl set-locale LANG=en_US.UTF-8
sudo dnf install -y epel-release
sudo dnf install -y neovim git tree which
sudo dnf install -y python3-pip
pip install --user ansible
#sudo dnf install -y ansible
ansible-galaxy collection install community.docker
curl https://starship.rs/install.sh > install.sh
sh install.sh -y
echo "set -o vi" >> ~/.bashrc
echo 'eval "$(starship init bash)"' >> ~/.bashrc
